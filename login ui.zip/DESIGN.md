---
name: Urban Pulse AI
colors:
  surface: '#10131b'
  surface-dim: '#10131b'
  surface-bright: '#363942'
  surface-container-lowest: '#0b0e16'
  surface-container-low: '#181c23'
  surface-container: '#1c2028'
  surface-container-high: '#272a32'
  surface-container-highest: '#31353d'
  on-surface: '#e0e2ed'
  on-surface-variant: '#c1c6d7'
  inverse-surface: '#e0e2ed'
  inverse-on-surface: '#2d3039'
  outline: '#8b90a0'
  outline-variant: '#414755'
  surface-tint: '#adc6ff'
  primary: '#adc6ff'
  on-primary: '#002e69'
  primary-container: '#4b8eff'
  on-primary-container: '#00285c'
  inverse-primary: '#005bc1'
  secondary: '#53e16f'
  on-secondary: '#003911'
  secondary-container: '#05b046'
  on-secondary-container: '#003a11'
  tertiary: '#ffb874'
  on-tertiary: '#4b2800'
  tertiary-container: '#d47b00'
  on-tertiary-container: '#412200'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#adc6ff'
  on-primary-fixed: '#001a41'
  on-primary-fixed-variant: '#004493'
  secondary-fixed: '#72fe88'
  secondary-fixed-dim: '#53e16f'
  on-secondary-fixed: '#002107'
  on-secondary-fixed-variant: '#00531c'
  tertiary-fixed: '#ffdcbf'
  tertiary-fixed-dim: '#ffb874'
  on-tertiary-fixed: '#2d1600'
  on-tertiary-fixed-variant: '#6a3b00'
  background: '#10131b'
  on-background: '#e0e2ed'
  surface-variant: '#31353d'
typography:
  headline-xl:
    fontFamily: Hanken Grotesk
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 48px
---

## Brand & Style

The design system is built on a foundation of **Glassmorphism** and **Minimalism**, tailored for a mature civic-tech environment. The aesthetic moves away from aggressive "cyberpunk" tropes in favor of a "Liquid Glass" language inspired by high-end spatial computing (VisionOS). It evokes an emotional response of authority, calm, and precision.

The style relies on high-quality environmental blurs, realistic light refraction on edges, and a sophisticated "smoked" transparency. The target audience includes city officials, urban planners, and high-level stakeholders who require an expensive, institutional tool that feels cutting-edge yet grounded.

## Colors

The palette is anchored by a deep charcoal blue background (`#0A0E14`), providing a dense, ink-like canvas. 

- **Primary (iOS Blue):** Used sparingly for critical interactive paths and primary actions.
- **Semantic Accents:** Soft Emerald for success/stability, Warm Amber for cautions, and Controlled Coral Red for emergencies.
- **Glass Surfaces:** Two primary tiers of glass—Smoked Navy for main navigational elements and Translucent Graphite for modular cards.
- **Text Tones:** Headings utilize a warm near-white to reduce eye strain, while secondary metadata uses a cool slate grey to establish hierarchy.

## Typography

This design system uses **Hanken Grotesk** for headlines to mimic the precision of SF Pro, providing a clean, authoritative "Adwaita" feel. **Inter** is utilized for body and UI labels due to its exceptional legibility on high-resolution displays and systematic utility.

Contrast is maintained through color rather than weight alone; use the warm near-white for high-priority information and cool slate grey for supporting text. All headings feature slightly tightened letter spacing to ensure a compact, professional appearance.

## Layout & Spacing

The layout follows a **strict 8-point grid system** to maintain mathematical harmony. 

- **Grid Model:** A 12-column fluid grid for desktop with 24px gutters. On mobile, transition to a 4-column grid with 16px margins.
- **Containers:** Content is housed in floating glass panels rather than edge-to-edge strips. Use the `xl` (32px) spacing for internal padding of major panels to emphasize the premium feel of "air."
- **Reflow:** For tablet and desktop, panels should maintain a maximum width of 1440px to ensure data density remains manageable for the human eye.

## Elevation & Depth

Depth is achieved through **Backdrop Blurs** and **Edge Highlights** rather than traditional drop shadows.

1.  **The Base Layer:** The background is a solid deep charcoal blue.
2.  **The Glass Layer:** Surfaces use a 20px - 30px backdrop blur (Gaussian). 
3.  **The Edge Highlight:** Every glass element must have a 1px inner border. The top and left edges use a 15% opacity white (simulating a light source from the top-left), while the bottom and right edges use a 5% opacity white.
4.  **Shadows:** When necessary to separate stacked glass, use a very large (64px blur), low-opacity (20%) black shadow with no offset.

## Shapes

The shape language is sophisticated and organic, using high-radius corners to soften the "civic data" experience.

- **Primary Panels:** Use 24px for large dashboard containers and main windows.
- **Cards & Modals:** Use 18px to nest comfortably inside panels.
- **Interactive Elements:** Inputs and small buttons use 14px.
- **Buttons & Nav:** All primary buttons and the floating navigation bar utilize full-round "Pill" shapes for a modern, fluid aesthetic.

## Components

- **Floating Glass Navbar:** A pill-shaped smoked navy container floating at the top or bottom of the viewport. Use a 1px white-to-transparent gradient border.
- **Pill Buttons:** Primary buttons are fully rounded with a solid iOS Blue fill. Secondary buttons use a glass background with a subtle white stroke.
- **Glass Cards:** Feature an 18px radius, Smoked Navy glass, and internal 24px padding. 
- **Input Fields:** 14px radius with a Translucent Graphite fill. The border should illuminate to iOS Blue on focus.
- **Lists:** Use subtle 1px horizontal dividers in 10% opacity white. Ensure 16px vertical padding between list items.
- **Chips/Status:** Use the semantic colors (Emerald, Amber, Coral) in a low-opacity "tinted glass" style with a high-contrast label.
- **Floating Action Buttons (FAB):** Strictly circular, utilizing a vibrant iOS Blue with a centered icon, casting a soft ambient blue glow only on hover.