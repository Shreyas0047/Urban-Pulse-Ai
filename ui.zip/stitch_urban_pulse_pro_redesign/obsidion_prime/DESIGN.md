---
name: Obsidion Prime
colors:
  surface: '#111417'
  surface-dim: '#111417'
  surface-bright: '#37393d'
  surface-container-lowest: '#0c0e12'
  surface-container-low: '#191c1f'
  surface-container: '#1d2023'
  surface-container-high: '#282a2e'
  surface-container-highest: '#323539'
  on-surface: '#e1e2e7'
  on-surface-variant: '#c2c6d6'
  inverse-surface: '#e1e2e7'
  inverse-on-surface: '#2e3134'
  outline: '#8c909f'
  outline-variant: '#424754'
  surface-tint: '#adc6ff'
  primary: '#adc6ff'
  on-primary: '#002e6a'
  primary-container: '#4d8eff'
  on-primary-container: '#00285d'
  inverse-primary: '#005ac2'
  secondary: '#b7c8e1'
  on-secondary: '#213145'
  secondary-container: '#3a4a5f'
  on-secondary-container: '#a9bad3'
  tertiary: '#ffb95f'
  on-tertiary: '#472a00'
  tertiary-container: '#ca8100'
  on-tertiary-container: '#3e2400'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#adc6ff'
  on-primary-fixed: '#001a42'
  on-primary-fixed-variant: '#004395'
  secondary-fixed: '#d3e4fe'
  secondary-fixed-dim: '#b7c8e1'
  on-secondary-fixed: '#0b1c30'
  on-secondary-fixed-variant: '#38485d'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#111417'
  on-background: '#e1e2e7'
  surface-variant: '#323539'
typography:
  display-lg:
    fontFamily: Hanken Grotesk
    fontSize: 72px
    fontWeight: '800'
    lineHeight: 80px
    letterSpacing: -0.04em
  display-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 40px
    fontWeight: '800'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-caps:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.1em
  meta-data:
    fontFamily: Hanken Grotesk
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.02em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1440px
  gutter: 32px
  margin-desktop: 64px
  margin-mobile: 24px
  section-gap: 120px
---

## Brand & Style
The design system is a high-end, cinematic environment engineered for civic command and control. It balances the gravity of public infrastructure with the sophistication of luxury aerospace interfaces.

The aesthetic is **Cinematic Minimalism** mixed with **Glassmorphism**. It prioritizes deep, layered obsidian surfaces that create a sense of infinite digital space. The goal is to evoke a "Mission Control" atmosphere—serious, expensive, and technically precise. Visual tension is achieved through the juxtaposition of vast negative space and hyper-detailed data clusters. High-contrast typography and subtle glow trails guide the eye through complex operations, ensuring that the interface feels both authoritative and bespoke.

## Colors
The palette is rooted in the "Obsidian Tier" of darkness. The primary background is a deep ink (#05070a), providing a void-like canvas that allows illuminated elements to pop without causing eye strain. 

- **Primary (Electric Cobalt):** Reserved for active states, critical path actions, and data-driven focal points.
- **Secondary (Slate Blue):** Used for non-interactive structural elements, secondary iconography, and supporting metadata.
- **Tertiary (Critical Amber):** Strictly for warnings, alerts, and high-priority civic updates.
- **Surface Tones:** Charcoal (#0b0e14) and Obsidian (#12151c) are used to define distinct functional zones through subtle shifts in value rather than heavy borders.

## Typography
This design system utilizes **Hanken Grotesk** across all levels to maintain a cohesive, technical feel. The hierarchy is extreme: massive display headers establish a cinematic narrative, while metadata is rendered in tiny, high-precision weights.

- **Display Text:** Used for high-level civic metrics or page titles. It should be tightly kerned and bold.
- **Label Caps:** All-caps utility labels used for categorization and small buttons. This adds an editorial, structured feel.
- **Meta-data:** Used for timestamps, coordinates, and technical readings. It should always appear in Slate Blue to distinguish it from primary content.

## Layout & Spacing
The layout philosophy is built on **Luxurious Tension**. While it follows a 12-column grid for alignment, the system encourages "floating" components—elements that intentionally break the grid or overlap slightly to create depth.

- **Whitespace:** Use generous vertical gaps (120px+) between major sections to allow the interface to "breathe" and signal high-value information.
- **Fluidity:** Containers should be fluid up to 1440px, after which they center with wide margins. 
- **Reflow:** On mobile, margins shrink to 24px, and the 12-column grid collapses to a 4-column system, with heavy emphasis on vertical stacking of data cards.

## Elevation & Depth
Depth is the core of this design system. It is achieved through a combination of tonal layering and atmospheric effects.

- **Surfaces:** Use "Ultra-low-opacity glass" (White at 3-5% opacity) with a background blur of 20px-40px. This creates a frosted metallic look.
- **Strokes:** Use a "Metallic Stroke"—a 1px border colored `white / 0.05`. This creates a crisp edge that catches "light" in the dark environment.
- **Shadows:** Avoid harsh, black shadows. Instead, use "Deep Glows"—diffused shadows with a slight cobalt tint (`#3b82f6` at 10% opacity) for active elements. 
- **Glow Trails:** For progress bars or active data streams, add a soft 4px-8px outer glow in the primary color to simulate light emission.

## Shapes
The shape language is "Soft-Technical." Elements use a subtle **0.25rem (4px)** radius as a default to maintain a sharp, professional edge without being aggressive. 

Large containers and cards use **0.5rem (8px)** to soften the overall interface and make the "glass" panels feel more like physical sheets of material. Circular shapes are reserved exclusively for status indicators (LED style) and user avatars.

## Components
- **Buttons:** Primary buttons are solid Cobalt with white text. Secondary buttons use the Metallic Stroke with no fill. Interaction should trigger a subtle brightness increase rather than a color shift.
- **Input Fields:** Use the Obsidian background (#12151c) with a 1px Slate Blue bottom border. Focus state should illuminate the border in Cobalt and add a faint glow.
- **Cards:** Cards should be semi-transparent with a 40px backdrop blur. They should appear to "float" above the base layer, separated by a thin Metallic Stroke.
- **Chips:** Small, rectangular tags with 2px rounded corners. Use Slate Blue for categorized data and Amber for priority tags.
- **Civic Status Indicators:** High-gloss, "LED" style circles. Use a pulse animation for critical errors in Amber.
- **Data Visualizations:** Charts should use thin lines (1px) with gradient fills that fade into the background. Avoid solid fills to maintain the "cinematic" transparency.